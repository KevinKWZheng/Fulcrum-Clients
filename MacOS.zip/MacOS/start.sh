env/node/bin/npm install
echo "Setup complete"
env/node/bin/node dist/Client.js